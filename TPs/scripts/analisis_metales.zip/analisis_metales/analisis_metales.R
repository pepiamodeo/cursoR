
# análisis datos metales
# los datos están en el csv
# separado por ;
# en el archivo original el decimal está indicado con ,

# cargo los datos
datos <- read.csv("./datos/datos_metales.csv",sep=";",dec=",")

# tocar el iconito azul para desplegar el contenido del dataframe en el area de trabajo
# chequear si las variables están bien cargadas

# convierto en factor las variables ZONA y FECHA que son de texto (chr)
datos$ZONA <- as.factor(datos$ZONA)

# me faltó una no? ese va a ser tu aporte

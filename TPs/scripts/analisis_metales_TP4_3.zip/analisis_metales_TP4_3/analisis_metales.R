
# análisis datos metales
# los datos están en el csv
# separado por ;
# en el archivo original el decimal está indicado con ,

# cargo los datos
datos <- read.csv("./datos/datos_metales.csv",sep=";",dec=",")

# tocar el iconito azul para desplegar el contenido del dataframe en el area de trabajo
# chequear si las variables están bien cargadas

# convierto en factor las variables de texto (chr)
datos$ZONA <- as.factor(datos$ZONA)
datos$FECHA <- as.factor(datos$FECHA)

# cargo los datos alternativos de la carpeta datos
# prestar atención a la ruta

datos1 <- read.csv("./datos/datos_metales1.csv",sep=";",dec=",")

datos1$ZONA <- as.factor(datos1$ZONA)
datos1$FECHA <- as.factor(datos1$FECHA)

# son iguales los dataframe datos y datos1? ¿seguro/a?

# tocar el iconito azul para desplegar el contenido del dataframe en el area de trabajo
# chequear si las variables están bien cargadas

# si encontraste algún problema 
# abrí el csv con tu editor de planillas de calculo favorito
# corregí lo que haya que corregir, guardalo
# volvé a rstudio, limpia el area de trabajo y volvé a correr el script

# repetí la acción con todos los archivos que hay en la carpeta
# en cada caso vas a tener que editar y corregir distintas cosas

# la función levels() te puede ayudar mucho en algunos casos
